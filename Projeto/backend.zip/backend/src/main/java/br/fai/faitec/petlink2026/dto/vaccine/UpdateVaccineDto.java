package br.fai.faitec.petlink2026.dto.vaccine;

import br.fai.faitec.petlink2026.domain.vaccine.VaccineModel;

import java.sql.Date;
import java.sql.Timestamp;

public class UpdateVaccineDto {


    private Date applicationDate;
    private Date expirationDate;
    private String name;
    private String description;
    private String lote;

    public VaccineModel toVaccineModel() {
        VaccineModel vaccineModel = new VaccineModel();
        vaccineModel.setName(name);
        vaccineModel.setBatch(lote);
        vaccineModel.setDescription(description);
        vaccineModel.setExpirationDate(expirationDate);
        vaccineModel.setApplicationDate(applicationDate);

        return vaccineModel;
    }

    public Date getApplicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(Date applicationDate) {
        this.applicationDate = applicationDate;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLote() {
        return lote;
    }

    public void setLote(String lote) {
        this.lote = lote;
    }
}
