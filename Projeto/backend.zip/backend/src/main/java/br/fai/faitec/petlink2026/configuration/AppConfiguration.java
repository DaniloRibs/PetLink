package br.fai.faitec.petlink2026.configuration;

import br.fai.faitec.petlink2026.ports_and_adapters.adapter.dao.adoption.AdoptionPostgresDaoAdapter;
import br.fai.faitec.petlink2026.ports_and_adapters.adapter.dao.animal.FarmAnimalPostgresDaoAdapter;
import br.fai.faitec.petlink2026.ports_and_adapters.adapter.dao.announcement.AnnouncementPostgresDaoAdapter;
import br.fai.faitec.petlink2026.ports_and_adapters.adapter.dao.animal.PetPostgresDaoAdapter;
import br.fai.faitec.petlink2026.ports_and_adapters.adapter.dao.sale.FarmAnimalSalePostgresDaoAdapter;
import br.fai.faitec.petlink2026.ports_and_adapters.adapter.dao.user.EnterprisePostgresDaoAdapter;
import br.fai.faitec.petlink2026.ports_and_adapters.adapter.dao.user.PersonPostgresDaoAdapter;
import br.fai.faitec.petlink2026.ports_and_adapters.adapter.dao.user.UserPostgresDaoAdapter;
import br.fai.faitec.petlink2026.ports_and_adapters.adapter.dao.vaccine.VaccinePostgresDaoAdapter;
import br.fai.faitec.petlink2026.ports_and_adapters.adapter.service.security.basic.BasicAuthenticationServiceAdapter;
import br.fai.faitec.petlink2026.ports_and_adapters.adapter.service.security.jwt.JwtAuthenticationServiceAdapter;
import br.fai.faitec.petlink2026.ports_and_adapters.port.dao.adoption.AdoptionDao;
import br.fai.faitec.petlink2026.ports_and_adapters.port.dao.animal.FarmAnimalDao;
import br.fai.faitec.petlink2026.ports_and_adapters.port.dao.announcement.AnnouncementDao;
import br.fai.faitec.petlink2026.ports_and_adapters.port.dao.animal.PetDao;
import br.fai.faitec.petlink2026.ports_and_adapters.port.dao.sale.FarmAnimalSaleDao;
import br.fai.faitec.petlink2026.ports_and_adapters.port.dao.user.EnterpriseDao;
import br.fai.faitec.petlink2026.ports_and_adapters.port.dao.user.PersonDao;
import br.fai.faitec.petlink2026.ports_and_adapters.port.dao.user.UserDao;
import br.fai.faitec.petlink2026.ports_and_adapters.port.dao.vaccine.VaccineDao;
import br.fai.faitec.petlink2026.ports_and_adapters.port.service.security.AuthenticationService;
import br.fai.faitec.petlink2026.ports_and_adapters.port.service.user.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.sql.Connection;
import java.util.Arrays;

@Configuration
public class AppConfiguration {

    private final Environment environment;

    public AppConfiguration(Environment environment) {
        this.environment = environment;
        System.out.println("-------------------------");
        System.out.println("Active profile: " + Arrays.toString(environment.getActiveProfiles()));
        System.out.println("-------------------------");
    }

//    @Bean
//    public UserDao getUserFakeDao() {
//        return new UserFakeDaoAdapter();
//    }

//    @Bean
//    public PetDao getPetFakeDao() {
//        return new PetFakeDaoAdapter();
//    }


    @Bean
    public UserDao getUserPostgresDao(final Connection connection) {
        return new UserPostgresDaoAdapter(connection);
    }

    @Bean
    public PersonDao getPersonPostgresDao(final Connection connection) {
        return new PersonPostgresDaoAdapter(connection);
    }

    @Bean
    public EnterpriseDao getEnterprisePostgresDao(final Connection connection) {
        return new EnterprisePostgresDaoAdapter(connection);
    }

    @Bean
    public PetDao getPetPostgresDao(final Connection connection) {
        return new PetPostgresDaoAdapter(connection);
    }

    @Bean
    public VaccineDao getVaccinePostgresDao(final Connection connection) {
        return new VaccinePostgresDaoAdapter(connection);
    }

    @Bean
    public AnnouncementDao getAnnouncementPostgresDao(final Connection connection) {
        return new AnnouncementPostgresDaoAdapter(connection);
    }

    @Bean
    public AdoptionDao getAdoptionPostgresDao(final Connection connection) {
        return new AdoptionPostgresDaoAdapter(connection);
    }

    @Bean
    public FarmAnimalDao getFarmAnimalPostgresDao(final Connection connection) {
        return new FarmAnimalPostgresDaoAdapter(connection);
    }
    @Bean
    public FarmAnimalSaleDao getFarmAnimalSalePostgresDao(final Connection connection) {
        return new FarmAnimalSalePostgresDaoAdapter(connection);
    }

    @Profile("basic")
    @Bean
    public AuthenticationService basicAuthenticationService(final UserService userService) {
        return new BasicAuthenticationServiceAdapter(userService, passwordEncoder());
    }

    @Profile("jwt")
    @Bean
    public AuthenticationService jwtAuthenticationService(final PasswordEncoder passwordEncoder, final UserService userService) {
        return new JwtAuthenticationServiceAdapter(passwordEncoder, userService);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}
