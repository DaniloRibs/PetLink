export interface AutheticatedUserDto {}
